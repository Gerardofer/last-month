import React from "react";
import HelloReact from "./components/HelloReact";

const App = () => <HelloReact />;

export default App;
