import React from "react";

const HelloReact = () => <p>Hello World!</p>;

export default HelloReact;
