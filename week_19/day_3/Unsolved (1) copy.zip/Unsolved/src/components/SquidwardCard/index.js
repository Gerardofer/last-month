export { default } from "./SquidwardCard";
