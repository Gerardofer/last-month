export { default } from "./DeleteBtn";
