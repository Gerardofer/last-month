import React from "react";
import OmdbContainer from "./components/OmdbContainer";

const App = () => <OmdbContainer />;

export default App;
